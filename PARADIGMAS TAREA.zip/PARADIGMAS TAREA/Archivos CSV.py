import csv

# Writing data to a CSV file
with open('file.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['column1', 'column2'])
